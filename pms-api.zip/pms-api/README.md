# PMS REST API

Oracle PMS 系統的 REST API 服務，為 LINE Bot 提供訂單查詢功能。

## 📋 功能

- ✅ 查詢訂單（依姓名或電話）
- ✅ 查詢單一訂單詳細資訊
- ✅ 查詢可用房間
- ⏳ 建立新訂單（開發中）
- ⏳ 取消訂單（開發中）

## 🚀 快速開始

### 1. 安裝依賴

```bash
cd pms-api
npm install
```

### 2. 配置環境變數

複製 `.env.example` 為 `.env`：

```bash
copy .env.example .env
```

編輯 `.env` 檔案，填入正確的資料庫連線資訊。

### 3. 啟動服務

**開發模式**（自動重啟）：
```bash
npm run dev
```

**正式模式**：
```bash
npm start
```

## 📡 API 端點

### 健康檢查
```
GET /api/health
```

### 查詢訂單
```
GET /api/bookings/search?name=王小明
GET /api/bookings/search?phone=0912345678
```

**回應範例**：
```json
{
  "success": true,
  "data": [
    {
      "booking_id": "00039201",
      "guest_name": "王小明",
      "contact_phone": "0912345678",
      "check_in_date": "2025-12-15",
      "check_out_date": "2025-12-17",
      "nights": 2,
      "status_code": "O",
      "status_name": "已確認"
    }
  ],
  "count": 1
}
```

### 查詢訂單詳情
```
GET /api/bookings/:booking_id
```

**回應範例**：
```json
{
  "success": true,
  "data": {
    "booking_id": "00039201",
    "guest_name": "王小明",
    "contact_phone": "0912345678",
    "check_in_date": "2025-12-15",
    "check_out_date": "2025-12-17",
    "nights": 2,
    "status_code": "O",
    "status_name": "已確認",
    "remarks": "素食",
    "rooms": [
      {
        "room_type_code": "ST",
        "room_type_name": "標準雙人房",
        "room_count": 1,
        "adult_count": 2,
        "child_count": 0
      }
    ]
  }
}
```

### 查詢可用房間
```
GET /api/rooms/availability?check_in=2025-12-15&check_out=2025-12-17
```

**回應範例**：
```json
{
  "success": true,
  "data": {
    "check_in": "2025-12-15",
    "check_out": "2025-12-17",
    "rooms": [
      {
        "room_type_code": "ST",
        "room_type_name": "標準雙人房",
        "total_rooms": 10,
        "booked_rooms": 3,
        "available_rooms": 7,
        "is_available": true
      }
    ]
  }
}
```

## 🔧 Windows Server 部署

### 前置條件
- ✅ Node.js v20.10.0 已安裝
- ✅ Oracle Database 12c 運行中
- ✅ pms_api 帳號已創建並授權

### 部署步驟

1. **複製專案到 Windows Server**
   ```powershell
   # 將 pms-api 資料夾複製到 C:\KTW-bot\
   ```

2. **安裝依賴**
   ```powershell
   cd C:\KTW-bot\pms-api
   npm install
   ```

3. **配置環境變數**
   ```powershell
   copy .env.example .env
   notepad .env
   ```
   
   確認設定：
   ```
   DB_USER=pms_api
   DB_PASSWORD=api123456
   DB_CONNECT_STRING=localhost:1521/gdwuukt
   ORACLE_CLIENT_LIB_DIR=D:\\app\\product\\12.2.0\\dbhome_1\\bin
   PORT=3000
   ```

4. **啟動服務**
   ```powershell
   npm start
   ```

5. **測試 API**
   ```powershell
   # 在瀏覽器開啟
   http://localhost:3000/api/health
   ```

### 設定為 Windows 服務（選用）

使用 PM2：
```powershell
npm install -g pm2
npm install -g pm2-windows-service
pm2-service-install
pm2 start server.js --name pms-api
pm2 save
```

## 🧪 測試

從 Mac 測試 Windows Server 上的 API：

```bash
# 健康檢查
curl http://192.168.8.3:3000/api/health

# 查詢訂單
curl "http://192.168.8.3:3000/api/bookings/search?name=王"

# 查詢訂單詳情
curl http://192.168.8.3:3000/api/bookings/00039201
```

## 📝 技術棧

- **框架**：Express.js
- **資料庫**：Oracle Database 12c
- **ORM**：oracledb (Thick 模式，支援中文字符集)
- **環境變數**：dotenv

## 🔐 安全性

- 使用專用帳號 `pms_api`（僅查詢權限）
- 連線池管理，避免資源耗盡
- 輸入參數驗證
- 錯誤訊息不洩漏敏感資訊

## 📈 下一步

- [ ] 整合到 LINE Bot
- [ ] 實作建立訂單 API
- [ ] 實作取消訂單 API
- [ ] 增加 API 認證機制
- [ ] 增加日誌記錄
- [ ] 效能優化

## 🆘 常見問題

### API 啟動失敗

**問題**：Oracle Client 初始化失敗

**解決**：檢查 `.env` 中的 `ORACLE_CLIENT_LIB_DIR` 路徑是否正確。

### 連線失敗

**問題**：無法連接資料庫

**解決**：
1. 檢查 Oracle 服務是否運行
2. 驗證帳號密碼是否正確
3. 確認防火牆設定
