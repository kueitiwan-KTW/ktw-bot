# Oracle PMS API - POC 測試

## 📋 目的

驗證能否成功從 Oracle PMS 資料庫查詢訂單資料。

## 🚀 快速開始

### 1. 安裝依賴

```bash
cd pms-api-poc
npm install
```

### 2. 配置環境變數

複製 `.env.example` 為 `.env`，並填入實際的資料庫密碼：

```bash
cp .env.example .env
nano .env  # 編輯檔案，填入 DB_PASSWORD
```

### 3. 執行測試

#### 測試 1：資料庫連線
```bash
npm test
```

**預期結果**：
- ✅ 連線成功
- ✅ 顯示 Oracle 版本

#### 測試 2：查詢訂單資料
```bash
npm run test-query
```

**預期結果**：
- ✅ 查到訂單資料
- ✅ 顯示訂房人姓名
- ✅ 顯示入住/退房日期
- ✅ 顯示房型資訊

## 📊 測試項目清單

- [ ] Oracle 資料庫連線成功
- [ ] 可查詢訂單主檔（ORDER_MN）
- [ ] 可查詢訂單明細（ORDER_DT）
- [ ] 可查詢房型資料（ROOM_RF）
- [ ] 資料格式符合 API 設計
- [ ] 回應時間 < 500ms

## ⚠️ 可能遇到的問題

### 問題 1：連線失敗
```
Error: ORA-01017: invalid username/password
```
**解決方法**：檢查 `.env` 中的 `DB_PASSWORD` 是否正確

### 問題 2：找不到資料表
```
Error: ORA-00942: table or view does not exist
```
**解決方法**：確認 Schema 名稱是否為 `TEST`

### 問題 3：找不到訂單
```
❌ 找不到訂單編號 00150501
```
**解決方法**：修改 `.env` 中的 `TEST_ORDER_ID` 為實際存在的訂單號

## 📝 下一步

當所有測試都通過後：
1. ✅ 建立完整的 Express API 服務
2. ✅ 實作 5 個 REST API 端點
3. ✅ 整合到 LINE BOT

## 🔗 相關文件

- [PMS API 規格](../docs/pms_api_specification.md)
- [資料庫結構](../docs/pms_database_structure.md)
